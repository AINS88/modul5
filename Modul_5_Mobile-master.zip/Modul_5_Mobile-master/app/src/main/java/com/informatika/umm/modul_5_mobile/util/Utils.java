package com.informatika.umm.modul_5_mobile.util;

/*
 * com.informatika.umm.modul_5_mobile.util
 * Created By robin
 * on 4/29/2020
 */
public class Utils {
   public static final String URL = "https://maps.googleapis.com/maps/";
   public static final String KEY = "AIzaSyDkl7m2dlcNNF9xqLSPGmRA-2GiUOz1VvU";
}
